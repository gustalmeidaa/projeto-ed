@include('site.templates.header')
@yield('content')
@include('site.templates.footer')